package com.example.crud_priya;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {
    dbo obj = new dbo(this,null,null,1);
    EditText ename,fname;
    Button btnUpdate,btnDelete;
    String oldName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        ename = findViewById(R.id.t1);
        fname = findViewById(R.id.fname);
        btnUpdate = findViewById(R.id.b3);
        btnDelete = findViewById(R.id.b4);

        ename.setText(getIntent().getExtras().getSerializable("Data").toString());
        fname.setText(getIntent().getExtras().getSerializable("Data1").toString());

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj.up_rec(getIntent().getExtras().getSerializable("Data").toString(),ename.getText().toString(),fname.getText().toString());
                Toast.makeText(getApplicationContext(),"Record Updated", Toast.LENGTH_LONG).show();
                startActivity(new Intent(UpdateActivity.this,showAllActivity.class));

            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj.del_rec(getIntent().getExtras().getSerializable("Data").toString());
                Toast.makeText(getApplicationContext(),"Record Deleted", Toast.LENGTH_LONG).show();
                startActivity(new Intent(UpdateActivity.this,showAllActivity.class));

            }
        });
    }
}