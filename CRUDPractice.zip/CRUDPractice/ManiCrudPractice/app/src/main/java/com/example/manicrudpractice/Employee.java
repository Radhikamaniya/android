package com.example.manicrudpractice;

public class Employee {
    private int empId;
    private String empName;
    private String empSalary;
    private byte[] empImage;


    public Employee(int empId, String empName,String empSalary, byte[] empImage) {
        this.empId = empId;
        this.empName = empName;
        this.empSalary = empSalary;
        this.empImage = empImage;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpSalary() {
        return empSalary;
    }

    public void setEmpSalary(String empSalary) {
        this.empSalary = empSalary;
    }

    public byte[] getEmpImage() {
        return empImage;
    }

    public void setEmpImage(byte[] empImage) {
        this.empImage = empImage;
    }
}
