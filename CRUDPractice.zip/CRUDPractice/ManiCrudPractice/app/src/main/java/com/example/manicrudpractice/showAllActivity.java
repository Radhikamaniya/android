package com.example.manicrudpractice;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class showAllActivity extends AppCompatActivity {

    dbo obj  = new dbo(this,null,null,1);
    ListView lv ;
    List<Employee> empList;
    EmployeeAdapter empadp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all);

        lv = findViewById(R.id.listview);
        empList = new ArrayList<>();
        Cursor c;
        c = obj.getData();
        if(c.getCount() > 0) {
            c.moveToFirst();
            do {
                empList.add(new Employee(
                        c.getInt(0),
                        c.getString(1),
                        c.getString(2),
                        c.getBlob(3)
                ));
            } while (c.moveToNext());
            c.close();
            empadp = new EmployeeAdapter(this, R.layout.list_layout_employee, empList);
            lv.setAdapter(empadp);
        }
        else
        {
            Toast.makeText(getApplicationContext(),"no data found",Toast.LENGTH_LONG).show();
        }

    }
}