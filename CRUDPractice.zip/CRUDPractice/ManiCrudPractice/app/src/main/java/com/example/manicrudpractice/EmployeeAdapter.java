package com.example.manicrudpractice;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class EmployeeAdapter extends ArrayAdapter<Employee> {
    Context context;
    int resourse;
    List<Employee> elist;
    dbo obj;

    EditText editName,editSalary;
    ImageView empEditImg;
    Button ediBtn,editChoosebtn;
    int i = 1;
    private int [] drawableimages={R.drawable.image1,R.drawable.image2,R.drawable.image3};

    public EmployeeAdapter(@NonNull Context context, int resource, @NonNull List<Employee> elist) {
        super(context, resource, elist);

        this.context = context;
        this.resourse = resource;
        this.elist = elist;
        obj = new dbo(this.context,null,null,1);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater =LayoutInflater.from(context);
        View view =inflater.inflate(resourse,null);

        Employee emp =elist.get(position);

        TextView txtviewempName =view.findViewById(R.id.txtemployeEname);
        TextView txtviewempSalary =view.findViewById(R.id.txtemployeeSalary);
        ImageView txtviewempimage =view.findViewById(R.id.imageView2);

        txtviewempName.setText(emp.getEmpName());
        txtviewempSalary.setText(emp.getEmpSalary());

        byte[] empImage = emp.getEmpImage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(empImage,0,empImage.length);
        txtviewempimage.setImageBitmap(bitmap);

        //Button
        Button btnEdit = view.findViewById(R.id.buttonEditEmployee);
        Button btnDelete = view.findViewById(R.id.buttonDeleteEmployee);

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editEmploee(emp);
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Are u sure delete?");
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String id = Integer.toString(emp.getEmpId());
                        obj.deleteData(id);
                        Intent intent =new Intent(context,showAllActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent);
                    }
                });
                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                AlertDialog dialog= builder.create();
                dialog.show();
            }
        });
        return view;
    }
    public void editEmploee(Employee em)
    {
        AlertDialog.Builder builder =new AlertDialog.Builder(context);
        LayoutInflater inflater =LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.activity_update,null);

        builder.setView(view);

        editName = view.findViewById(R.id.editempname);
        editSalary = view.findViewById(R.id.editempsalary);
        empEditImg = view.findViewById(R.id.editempimg);
        ediBtn = view.findViewById(R.id.buttonEditEmployee);
        editChoosebtn = view.findViewById(R.id.editbtnchoose);


        editName.setText(em.getEmpName());
        editSalary.setText(em.getEmpSalary());

        //radioBtn.setText(em.getEmpGender());

        byte[] empImage = em.getEmpImage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(empImage,0,empImage.length);
        empEditImg.setImageBitmap(bitmap);

        AlertDialog dialog = builder.create();
        dialog.show();

        editChoosebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                ActivityCompat.requestPermissions((Activity) context,
//                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
//                        888);
                if(i==4)
                {
                    i=1;
                }
                empEditImg.setImageResource(drawableimages[i]);
                i++;

            }
        });

        view.findViewById(R.id.btnEdit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try{
                    obj.updateData(Integer.toString(em.getEmpId()),
                            editName.getText().toString(),
                            editSalary.getText().toString(),
                            imgviewToByte());
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                Toast.makeText(context,"Data Updated!!",Toast.LENGTH_SHORT).show();

                Intent intent =new Intent(context,showAllActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }
    private byte[] imgviewToByte(){
        Bitmap bmap = ((BitmapDrawable)empEditImg.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
        byte[] byteArr = stream.toByteArray();
        return byteArr;
    }
}
