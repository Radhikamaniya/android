package com.example.manicrudpractice;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbo extends SQLiteOpenHelper {
    public dbo(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "employeeDB", factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table employeetable (id integer primary key AUTOINCREMENT,empName text,salary text,empImg BLOB)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        onCreate(db);
    }
    public void addData(String name,String salary,byte[] image)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("empName",name);
        cv.put("salary",salary);
        cv.put("empImg",image);
        db.insert("employeetable",null,cv);
        db.close();
    }

    public Cursor getData()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from employeetable",null);
        return res;
    }

    public void updateData(String id,String name,String salary,byte[] image)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("empName",name);
        cv.put("salary",salary);
        cv.put("empImg",image);
        db.update("employeetable",cv,"id = ?", new String[]{id});
        db.close();
    }

    public void deleteData(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("employeetable","id = ?" , new String[]{id});
        db.close();
    }
}
