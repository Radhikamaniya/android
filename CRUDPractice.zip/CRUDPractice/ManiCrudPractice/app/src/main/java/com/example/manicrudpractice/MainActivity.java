package com.example.manicrudpractice;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    EditText name,salary,gender;
    Button bChoose,bAdd,bGetAll;
    ImageView eImage;
    String rm;
    dbo obj = new dbo(this,null,null,1);
    final int REQUEST_CODE_GALLARY = 999;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.empname);
        salary = findViewById(R.id.empsalary);

        eImage = findViewById(R.id.empimg);
        bChoose = findViewById(R.id.btnchoose);
        bAdd = findViewById(R.id.btnAdd);
        bGetAll = findViewById(R.id.btnDisplay);

        bChoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Requests permissions to be granted to this application. These permissions must be requested in your manifest,
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        REQUEST_CODE_GALLARY); //999=request_code_gallery
            }
        });

        bAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    obj.addData(name.getText().toString(),
                            salary.getText().toString(),
                            imgviewToByte());
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                Toast.makeText(getApplicationContext(),"Data Inserted!!",Toast.LENGTH_SHORT).show();
                name.setText("");
                salary.setText("");
                eImage.setImageResource(R.mipmap.ic_launcher);
            }
        });

        bGetAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,showAllActivity.class));
            }
        });
    }

    private byte[] imgviewToByte(){
        //A bitmap (or raster graphic) is a digital image composed of a matrix of dots
        Bitmap bmap = ((BitmapDrawable)eImage.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
        byte[] byteArr = stream.toByteArray();
        return byteArr;
    }
    //Callback for the result from requesting permissions. This method is invoked for every call on requestPermissions.
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == REQUEST_CODE_GALLARY)
        {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), REQUEST_CODE_GALLARY);
                //startActivityForResult(intent,REQUEST_CODE_GALLARY);
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Not Permission", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    //If >= 0, this code will be returned in onActivityResult() when the activity exits.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == REQUEST_CODE_GALLARY && resultCode == RESULT_OK && data != null)
        {
            Uri uri = data.getData();
            try{
                InputStream is = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(is);
                eImage.setImageBitmap(bitmap);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}