package com.example.e_vottingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    TextView txthomewlc;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        SharedPreferences sf = getSharedPreferences("mypref",MODE_PRIVATE);
        if(item.getItemId() == R.id.itemlogout)
        {
            SharedPreferences.Editor editor  = sf.edit();
            editor.clear();
            editor.commit();
            finish();
            Toast.makeText(getApplicationContext(),"Log out Successfully",Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        txthomewlc = findViewById(R.id.txtHomeWlc);

        SharedPreferences sf = getSharedPreferences("mypref",MODE_PRIVATE);
        String emailSf = sf.getString("email",null);
        if(emailSf != null)
        {
            txthomewlc.setText(emailSf);
        }
        else
        {
            Intent i = getIntent();
            String email = i.getStringExtra("email");
            txthomewlc.setText(email);
        }
    }
}