package com.example.patient_tracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class showActivity extends AppCompatActivity {
    dbo obj = new dbo(this,null,null,1);
    Button insert;
    private SimpleCursorAdapter adapter;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        SharedPreferences sf = getSharedPreferences("mypref",MODE_PRIVATE);
        if(item.getItemId() == R.id.logout)
        {
            SharedPreferences.Editor editor  = sf.edit();
            editor.clear();
            editor.commit();
            finish();
            Toast.makeText(getApplicationContext(),"Log out Successfully",Toast.LENGTH_SHORT).show();
            Intent i = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(i);

        }
        return true;
    }

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        ListView lv;
        List<String> ls = new ArrayList<>();
        List<String> fls = new ArrayList<>();
        lv=findViewById(R.id.lv1);
        insert=findViewById(R.id.insertpatient);
        Cursor c;
        c=obj.get_Data();
        if(c != null && !c.isClosed())
        {
            c.moveToFirst();
            do{
                ls.add(c.getString(c.getColumnIndex("pname")).toString());
                fls.add(c.getString(c.getColumnIndex("pdisease")).toString());
            }while (c.moveToNext());

            ArrayAdapter<String> adp=new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, ls);
            lv.setAdapter(adp);
        }
        else
        {
            Toast.makeText(getApplicationContext(),"No Data", Toast.LENGTH_LONG).show();
        }
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent(showActivity.this,UpdateActivity.class);
                intent.putExtra("Data",ls.get(position));
                intent.putExtra("Data1",fls.get(position));
                startActivity(intent);
            }
        });
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                obj.add_patient();
                Toast.makeText(getApplicationContext(),"Data Inserted", Toast.LENGTH_LONG).show();

                Intent i = new Intent(getApplicationContext(),InsertActivity.class);
                startActivity(i);
            }
        });

//        for menu of logout

    }
}