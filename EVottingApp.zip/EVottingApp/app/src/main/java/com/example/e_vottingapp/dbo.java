package com.example.e_vottingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;


public class dbo extends SQLiteOpenHelper {
    public static final String TABLE_NAME = "voter";
    public static final String Key_rowID = "_id";
    public static final String KEY_NAME = "name";
    public static final String Key_email = "email";
    public static final String Key_psw = "psw";
    public static final String Key_dob = "dob";
    public static final String Key_city = "city";
    Context context;
    public dbo(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context,"evotingDB", factory, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table voter(_id integer primary key autoincrement,name text,email text,psw text,dob text,city text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists voter");
    }

    public boolean addVoter(String name,String email,String psw,String dob,String city)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_NAME,name); // 1st table column name
        cv.put(Key_email,email);
        cv.put(Key_psw,psw);
        cv.put(Key_dob,dob);
        cv.put(Key_city,city);
        long result =  db.insert(TABLE_NAME,null,cv); // tbalename ,
        if(result == 1)  return false;
        else
            return true;
    }

    public boolean checkemail(String email)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("select * from voter where email = ?",new String[]{email});
        if(c.getCount()>0)
            return  true;
        else
            return  false;
    }

    public boolean checkemailpsw(String email,String psw)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor c = db.rawQuery("select * from voter where email = ? and psw = ?",new String[]{email,psw});
        if(c.getCount()>0)

            return  true;
        else
            return  false;
    }

}
