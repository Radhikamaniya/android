package com.example.patient_tracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {
    dbo obj = new dbo(this,null,null,1);

    EditText name,email,pass,doa,cost,meditation,disease;

    public String text;
    Button update,delete;
    String oldName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        update=findViewById(R.id.update);
        delete=findViewById(R.id.delete);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        pass = findViewById(R.id.pass);
        doa = findViewById(R.id.doa);
        cost=findViewById(R.id.cost);
        disease=findViewById(R.id.disease);
        meditation=findViewById(R.id.meditation);

        name.setText(getIntent().getExtras().getSerializable("Data").toString());
        disease.setText(getIntent().getExtras().getSerializable("Data1").toString());
update.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        obj.up_rec(getIntent().getExtras().getSerializable("Data").toString(),name.getText().toString(),disease.getText().toString());
        Toast.makeText(getApplicationContext(),"Record Updated", Toast.LENGTH_LONG).show();
        startActivity(new Intent(UpdateActivity.this,showActivity.class));

    }
});
delete.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        obj.del_rec(getIntent().getExtras().getSerializable("Data").toString());
        Toast.makeText(getApplicationContext(),"Record Deleted", Toast.LENGTH_LONG).show();
        startActivity(new Intent(UpdateActivity.this,showActivity.class));

    }
});
    }
}