package com.example.e_vottingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Calendar;


public class RegisterVoterActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Button  btnRegisterSubmit;
    EditText txtname,txtemail,txtpsw,txtdob;
    Spinner txtcity;
    public String text;
    int mDate,mMonth,mYear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_voter);
        btnRegisterSubmit = findViewById(R.id.btnRegistrationSubmit);
        txtname = findViewById(R.id.txtregname);
        txtemail = findViewById(R.id.txtregemail);
        txtpsw = findViewById(R.id.txtregpsw);
        txtdob = findViewById(R.id.txtdob);
        txtcity = findViewById(R.id.spinnerCity);

        dbo db = new dbo(getApplicationContext(),null,null,1);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.city, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        txtcity.setAdapter(adapter);


        txtdob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Calendar cal = Calendar.getInstance();
                mDate = cal.get(Calendar.DATE);
                mMonth = cal.get(Calendar.MONTH);
                mYear = cal.get(Calendar.YEAR);
                DatePickerDialog datePickerDialog = new DatePickerDialog(RegisterVoterActivity.this, android.R.style.Theme_DeviceDefault_Light_Dialog, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int date) {
                       txtdob.setText(date+"/"+month+"/"+year);
                    }
                },mYear,mMonth,mDate);
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis()-1000);
                datePickerDialog.show();
            }
        });

        btnRegisterSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             String  name= txtname.getText().toString();
             String  email = txtemail.getText().toString();
             String psw = txtpsw.getText().toString();
             String dob = txtdob.getText().toString();
             String city = String.valueOf(txtcity.getSelectedItem());
                 if(email.equals("") || name.equals("") || psw.equals("") || dob.equals(""))
                     Toast.makeText(getApplicationContext(),"Please enter all the information", Toast.LENGTH_SHORT).show();
                 else{
                     Boolean checkemail = db.checkemail(email);
                     if(checkemail == false)
                     {
                         Boolean insert =  db.addVoter(name,email,psw,dob,city);
                         if(insert == true)
                         {
                             txtname.setText("");
                             txtemail.setText("");
                             txtpsw.setText("");
                             txtdob.setText("");
                             Toast.makeText(getApplicationContext(),"Registration Done", Toast.LENGTH_SHORT).show();
                             Intent i1 = new Intent(getApplicationContext(),HomeActivity.class);
                             i1.putExtra("email",email);
                             startActivity(i1);
                         }
                         else
                         {
                             Toast.makeText(getApplicationContext(),"Registration Failed", Toast.LENGTH_SHORT).show();
                         }
                     }
                     else
                     {
                         Toast.makeText(getApplicationContext(),"Email already exists!! ", Toast.LENGTH_SHORT).show();
                     }

                 }




            }
        });


    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        text = adapterView.getItemAtPosition(i).toString();
        Toast.makeText(this,text,Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


}