package com.example.e_vottingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    Button btnlogin,btnSignup;
    EditText txtloginemail,txtloginpsw;
    SharedPreferences sf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbo db = new dbo(getApplicationContext(),null,null,1);
        btnlogin = findViewById(R.id.btnLogin);
        btnSignup = findViewById(R.id.btnSignUp);
        txtloginemail = findViewById(R.id.txtloginemail);
        txtloginpsw = findViewById(R.id.txtloginpsw);

        sf = getSharedPreferences("mypref",MODE_PRIVATE);
        String semail = sf.getString("email",null);
        if(semail!=null)
        {
            Intent i = new Intent(getApplicationContext(),HomeActivity.class);
            startActivity(i);
        }
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              String email = txtloginemail.getText().toString();
              String psw = txtloginpsw.getText().toString();

              if(email.equals("")|| psw.equals(""))
                  Toast.makeText(getApplicationContext(), "Please Enter Login Credentials...", Toast.LENGTH_SHORT).show();
              else
              {

                  boolean checkemailpsw = db.checkemailpsw(email,psw);
                  if(checkemailpsw==true)
                  {
                      SharedPreferences.Editor editor = sf.edit();
                      editor.putString("email",email);
                      editor.putString("psw",psw);
                      editor.apply();
                      txtloginemail.setText("");
                      txtloginpsw.setText("");
                      Toast.makeText(getApplicationContext(), "Sign In Successfully", Toast.LENGTH_SHORT).show();
                      Intent i1 = new Intent(getApplicationContext(),HomeActivity.class);
                      startActivity(i1);
                  }
                  else
                  {
                      Toast.makeText(getApplicationContext(), "Invalid credentials...", Toast.LENGTH_SHORT).show();
                  }
              }
            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(getApplicationContext(),RegisterVoterActivity.class);
                startActivity(i1);
            }
        });


    }
}